# RoboNoto

'RoboNoto' is a experimental truetype font family for Korean Programmers. It has fixed-width glyphs of commonly used characters for programming. 'RoboNoto' is based on 'Roboto Mono' for Latin characters and 'Noto Sans' for Korean characters.

* Roboto Mono: <https://www.google.com/fonts/specimen/Roboto+Mono>
* Noto Sans: <https://www.google.com/get/noto/>

For detailed infomation, please visit here:

* http://한글코딩.org/글꼴실험.html

## LICENSE

Daehyun Kim 2016 OFL 1.1
